﻿Copy the xml files from DefaultConfig to the Config folder before making changes to prevent updates from overwriting any changes you have made.

The system will read config from DefaultConfig if the files don't exist in Config
